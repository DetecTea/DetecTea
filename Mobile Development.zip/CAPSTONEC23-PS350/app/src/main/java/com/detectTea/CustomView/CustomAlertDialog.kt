package com.detectTea.CustomView

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import com.detectTea.databinding.CustomAlertDialogBinding

class CustomAlertDialog(
    context: Context,
    private val message: Int,
    private val image: Int
) :
    AlertDialog(context) {

    private lateinit var binding: CustomAlertDialogBinding

    init {
        setCancelable(false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = CustomAlertDialogBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val messageView = binding.tvDescription
        messageView.setText(message)

        val imageView = binding.imageSuccess
        imageView.setImageResource(image)

        val dismissButton = binding.btnConfirm
        dismissButton.setOnClickListener {
            dismiss()
        }
    }
}