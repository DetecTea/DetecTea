package com.detectTea.UserInterface.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.detectTea.R
import com.detectTea.UserInterface.detail.DetailActivity
import com.detectTea.model.local.Tea

class DiseaseAdapter(private val context: Context, private val teaList: List<Tea>) :
    RecyclerView.Adapter<DiseaseAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgTea: ImageView = itemView.findViewById(R.id.img_disease)
        val tvScientificName: TextView = itemView.findViewById(R.id.tv_scientific_name)
        val tvCommonName: TextView = itemView.findViewById(R.id.tv_common_name)

        init {
            itemView.setOnClickListener {
                val position = adapterPosition
                val tea = teaList[position]
                val intent = Intent(context, DetailActivity::class.java)
                intent.putExtra("images", tea.images)
                intent.putExtra("scientific_name", tea.scientific_name)
                intent.putExtra("common_name", tea.common_name)
                intent.putExtra("description", tea.description)
                intent.putExtra("prevent", tea.prevent)
                context.startActivity(intent)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.item_disease, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val tea = teaList[position]
        holder.imgTea.setImageResource(tea.images)
        holder.tvScientificName.text = tea.scientific_name
        holder.tvCommonName.text = tea.common_name
    }

    override fun getItemCount(): Int {
        return teaList.size
    }
}