package com.detectTea.UserInterface.changepassword

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.detectTea.R
import com.detectTea.UserInterface.login.LoginActivity
import com.detectTea.databinding.ActivityChangePasswordBinding
import com.google.firebase.auth.FirebaseAuth

class ChangePasswordActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChangePasswordBinding
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChangePasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        changePasswordHandler()
        buttonBackHandler()
    }

    private fun buttonBackHandler() {
        binding.btnBack.setOnClickListener {
            startActivity(Intent(this@ChangePasswordActivity, LoginActivity::class.java))
            finish()
        }
    }

    private fun changePasswordHandler() {
        binding.btnChangePassword.setOnClickListener {
            val email = binding.edEmail.text.toString()
            val edEmail = binding.edEmail

            if (email.isEmpty()) {
                edEmail.error = getString(R.string.error_validation)
                edEmail.requestFocus()
                return@setOnClickListener
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                edEmail.error = getString(R.string.error_email)
                edEmail.requestFocus()
                return@setOnClickListener
            }

            FirebaseAuth.getInstance().sendPasswordResetEmail(email).addOnCompleteListener {
                if (it.isSuccessful) {
                    Toast.makeText(this, "Reset password url berhasil dikirim", Toast.LENGTH_SHORT)
                        .show()
                    startActivity(Intent(this@ChangePasswordActivity, LoginActivity::class.java))
                    finish()
                } else {
                    edEmail.error = "${it.exception?.message}"
                    edEmail.requestFocus()
                    return@addOnCompleteListener
                }
            }
        }
    }
}