package com.detectTea.UserInterface.detail

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.detectTea.R
import com.detectTea.databinding.ActivityDetailBinding

@Suppress("DEPRECATION")
class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        binding.btnBack.setOnClickListener {
            onBackPressed()
        }

        val imageViewTeaDetail: ImageView = findViewById(R.id.img_disease)
        val textViewScientificNameDetail: TextView = findViewById(R.id.tv_scientific_name)
        val textViewCommonNameDetail: TextView = findViewById(R.id.tv_common_name)
        val textViewDescriptionDetail: TextView = findViewById(R.id.tv_description)
        val textViewPreventDetail: TextView = findViewById(R.id.tv_prevent)

        val images = intent.getIntExtra("images", 0)
        val scientificName = intent.getStringExtra("scientific_name")
        val commonName = intent.getStringExtra("common_name")
        val description = intent.getStringExtra("description")
        val prevent = intent.getStringExtra("prevent")

        imageViewTeaDetail.setImageResource(images)
        textViewScientificNameDetail.text = scientificName
        textViewCommonNameDetail.text = commonName
        textViewDescriptionDetail.text = description
        textViewPreventDetail.text = prevent
    }
}