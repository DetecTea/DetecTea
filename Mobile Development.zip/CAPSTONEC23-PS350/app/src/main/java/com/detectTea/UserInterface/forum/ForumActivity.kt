package com.detectTea.UserInterface.forum

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.detectTea.R

class ForumActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forum)
    }
}