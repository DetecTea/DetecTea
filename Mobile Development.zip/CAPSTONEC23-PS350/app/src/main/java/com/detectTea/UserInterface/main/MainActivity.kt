package com.detectTea.UserInterface.main

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.detectTea.R
import com.detectTea.UserInterface.adapter.DiseaseAdapter
import com.detectTea.UserInterface.detection.DetectActivity
import com.detectTea.UserInterface.forum.ForumActivity
import com.detectTea.UserInterface.setting.SettingActivity
import com.detectTea.databinding.ActivityMainBinding
import com.detectTea.model.Api.ApiService
import com.detectTea.model.Api.response.WeatherData
import com.detectTea.model.local.TeaDisease
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

private const val BASE_URL = "https://api.openweathermap.org/data/2.5/"

@Suppress("NAME_SHADOWING", "DEPRECATION")
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var apiService: ApiService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = getString(R.string.home)

        val recyclerView: RecyclerView = findViewById(R.id.rv_disease)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val teaList = TeaDisease.generateTeaList()
        val adapter = DiseaseAdapter(this, teaList)
        recyclerView.adapter = adapter

        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        apiService = retrofit.create(ApiService::class.java)

        getWeatherData("Bogor")
    }

    private fun getWeatherData(city: String) {
        val apiKey = "de13cb84f4d1124a2c467cf80be8cf15"

        val call = apiService.getCurrentWeather(city, apiKey)
        call.enqueue(object : Callback<WeatherData> {
            override fun onResponse(call: Call<WeatherData>, response: Response<WeatherData>) {
                if (response.isSuccessful) {
                    val weatherData = response.body()
                    if (weatherData != null) {
                        val cityName = weatherData.name
                        val temperatureKelvin = weatherData.main.temp
                        val temperatureCelsius = temperatureKelvin - 273.15
                        val temperatureFormatted = String.format("%.1f°C", temperatureCelsius)
                        val description = weatherData.weather[0].description

                        binding.tvCity.text = cityName
                        binding.tvTemp.text = temperatureFormatted
                        binding.tvDescription.text = description
                    }
                } else {
                    Log.e("API Error", "Response error: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<WeatherData>, t: Throwable) {
                Log.e("API Error", "Request error: ${t.message}")
            }
        })
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.item_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.nav_setting -> {
                val intent = Intent(this@MainActivity, SettingActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.nav_detect -> {
                val intent = Intent(this@MainActivity, DetectActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.nav_forum -> {
                val intent = Intent(this@MainActivity, ForumActivity::class.java)
                startActivity(intent)
                true
            }
            else -> {
                return true
            }
        }
    }
}