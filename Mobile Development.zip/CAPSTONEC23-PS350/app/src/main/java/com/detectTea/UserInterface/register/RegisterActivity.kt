package com.detectTea.UserInterface.register

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.detectTea.CustomView.CustomAlertDialog
import com.detectTea.R
import com.detectTea.UserInterface.login.LoginActivity
import com.detectTea.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var firebaseAuth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        firebaseAuth = FirebaseAuth.getInstance()

        goToLoginHandler()
        registerButtonHandler()
    }

    private fun goToLoginHandler() {
        binding.tvLogin.setOnClickListener {
            val intent = Intent(this@RegisterActivity, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun registerButtonHandler() {
        binding.btnLogin.setOnClickListener {
            val email = binding.edEmail.text.toString()
            val password = binding.edPasswordregister.text.toString()
            val confirmPassword = binding.edUlangipassword.text.toString()

            showLoading(true)
            if (email.isNotEmpty() && password.isNotEmpty() && confirmPassword.isNotEmpty()) {
                if (password == confirmPassword) {
                    firebaseAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener {
                            if (it.isSuccessful) {
                                showLoading(false)
                                val intent =
                                    Intent(this@RegisterActivity, LoginActivity::class.java)
                                startActivity(intent)
                                finish()
                            } else {
                                showLoading(false)
                                CustomAlertDialog(
                                    this,
                                    R.string.error_register,
                                    R.drawable.error_image
                                )
                            }
                        }
                } else {
                    showLoading(false)
                    CustomAlertDialog(this, R.string.error_validation, R.drawable.error_image)
                }
            } else {
                showLoading(false)
                CustomAlertDialog(this, R.string.error_register, R.drawable.error_image)
            }
        }
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            binding.progressBar.visibility = View.GONE
        } else {
            binding.progressBar.visibility = View.VISIBLE
        }
    }
}