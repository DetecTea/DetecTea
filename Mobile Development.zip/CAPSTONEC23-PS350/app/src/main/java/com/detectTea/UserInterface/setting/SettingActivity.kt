package com.detectTea.UserInterface.setting

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import com.detectTea.R
import com.detectTea.UserInterface.login.LoginActivity
import com.detectTea.databinding.ActivitySettingBinding
import com.google.firebase.auth.FirebaseAuth

@Suppress("DEPRECATION")
class SettingActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        languageButtonHandler()
        contactButtonHandler()
        logoutButtonHandler()


        val currentUser = FirebaseAuth.getInstance().currentUser

        if (currentUser != null) {
            val userId = currentUser.uid
            val userEmail = currentUser.email
            binding.tvUserId.text = userId
            binding.tvEmail.text = userEmail
        } else {
            binding.tvUserId.text = getString(R.string.no_user_found)
            binding.tvEmail.text = getString(R.string.no_user_found)
        }

        binding.btnBack.setOnClickListener {
            onBackPressed()
        }
    }


    private fun languageButtonHandler() {
        binding.cvLanguage.setOnClickListener {
            val intent = Intent(Settings.ACTION_LOCALE_SETTINGS)
            startActivity(intent)
        }
    }

    private fun logoutButtonHandler() {
        binding.cvLogout.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            val intent = Intent(this@SettingActivity, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            finish()
        }
    }

    private fun contactButtonHandler() {
        binding.cvContact.setOnClickListener {
            val phoneNumber = "081349704315"
            val intent = Intent(Intent.ACTION_DIAL)
            intent.data = Uri.parse("tel:$phoneNumber")
            startActivity(intent)
        }
    }
}