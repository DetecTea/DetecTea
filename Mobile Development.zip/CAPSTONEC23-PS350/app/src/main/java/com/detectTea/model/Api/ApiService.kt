package com.detectTea.model.Api

import com.detectTea.model.Api.response.WeatherData
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @GET("weather")
    fun getCurrentWeather(
        @Query("q") city: String,
        @Query("appid") apiKey: String
    ): Call<WeatherData>
}