package com.detectTea.model.Api.response

data class WeatherData(
    val name: String,
    val main: MainData,
    val weather: List<WeatherInfo>
)

data class MainData(
    val temp: Double
)

data class WeatherInfo(
    val description: String
)
