package com.detectTea.model

sealed class Result<out R> private constructor() {
    object Loading : Result<Nothing>()
    data class Success<out T>(val data: T) : Result<T>()
    data class Error(val data: String) : Result<Nothing>()
}