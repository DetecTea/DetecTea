package com.detectTea.model

class ViewModelFactory {

}