package com.detectTea.model.local

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Tea(
    var images: Int,
    var scientific_name: String,
    var common_name: String,
    var description: String,
    var prevent: String
) : Parcelable