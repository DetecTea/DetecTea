package com.detectTea.model.local

import com.detectTea.R

object TeaDisease {
    private var data = arrayOf(
        arrayOf(
            R.drawable.algal_leaf,
            "Algal Leaf",
            "Alga",
            "Alga adalah organisme mikroskopis yang dapat tumbuh pada daun teh. Mereka biasanya muncul sebagai lapisan hijau atau coklat pada permukaan daun. Alga dapat merugikan tanaman teh dengan menghambat penyerapan sinar matahari dan mengurangi pertumbuhan daun.",
            "Untuk mencegahnya, penting untuk menjaga kebersihan kebun teh, menghindari genangan air, dan memastikan sirkulasi udara yang baik di antara tanaman teh."
        ),
        arrayOf(
            R.drawable.anthracnose,
            "Anthracnose",
            "Twig Blight",
            "Anthracnose: Anthracnose disebabkan oleh jamur Colletotrichum spp. dan dapat menyebabkan bercak coklat pada daun teh. Infeksi berat dapat mengakibatkan kerusakan daun dan mengurangi hasil panen.",
            "Pengendalian anthracnose melibatkan pemangkasan dan pembakaran daun yang terinfeksi, menjaga kebersihan kebun teh, serta penggunaan fungisida yang sesuai jika diperlukan."
        ),
        arrayOf(
            R.drawable.bird_eye_spot,
            "Bird Eye Spot",
            "Speckle Spot",
            "Penyakit ini disebabkan oleh jamur Phyllosticta spp. dan biasanya menyebabkan bercak berbentuk seperti mata burung pada daun teh. Daun yang terinfeksi akan mengering dan gugur.",
            "Mencegah bird eye spot melibatkan pemangkasan dan pembakaran daun yang terinfeksi, menjaga kebersihan kebun teh, dan mempertahankan kondisi lingkungan yang optimal."
        ),
        arrayOf(
            R.drawable.brown_light,
            "Brown Light",
            "Blister Blight",
            "Brown blight, juga dikenal sebagai blister blight, disebabkan oleh jamur Exobasidium vexans. Penyakit ini biasanya muncul sebagai bintik-bintik coklat keputihan pada daun teh yang kemudian berkembang menjadi gelembung. Gejala yang parah dapat menyebabkan daun gugur dan kerusakan tanaman.",
            "Pengendalian brown blight melibatkan pemangkasan dan pembakaran daun yang terinfeksi, menjaga kebersihan kebun teh, dan penggunaan fungisida yang sesuai jika diperlukan."
        ),
        arrayOf(
            R.drawable.red_leaf_spot,
            "Grey Light",
            "Grey Spot Blight",
            "Grey blight disebabkan oleh jamur Pestalotiopsis spp. dan sering terjadi pada daun muda teh. Penyakit ini ditandai dengan bercak abu-abu yang berkembang menjadi daerah mati yang meluas.",
            "Pengendalian grey blight melibatkan pemangkasan dan pembakaran daun yang terinfeksi, menjaga kebersihan kebun teh, dan penggunaan fungisida yang sesuai jika diperlukan."
        ),
        arrayOf(
            R.drawable.red_leaf_spot,
            "Red Leaf Spot",
            "Pekoe Spot",
            "Penyakit ini disebabkan oleh jamur Cephaleuros spp. dan biasanya muncul sebagai bintik-bintik merah pada daun teh. Infeksi yang parah dapat mengakibatkan kerusakan daun dan mengurangi kualitas teh.",
            "Pengendalian red rust spot melibatkan pemangkasan dan pembakaran daun yang terinfeksi, menjaga kebersihan kebun teh, dan penggunaan fungisida yang sesuai jika diperlukan."
        ),
        arrayOf(
            R.drawable.white_spot,
            "White Spot",
            "Blister Blight",
            "White Spot adalah penyakit yang disebabkan oleh jamur Ectoedemia spp. atau Ectoedemia camelliae. Penyakit ini ditandai dengan munculnya bercak putih kecil pada daun teh, yang kemudian dapat berkembang menjadi area yang lebih besar. Infeksi yang parah dapat menyebabkan kerusakan daun dan mengurangi pertumbuhan tanaman teh.",
            "Praktik budidaya yang baik, dimana Pastikan tanaman teh ditanam pada jarak yang cukup agar udara dapat sirkulasi dengan baik di antara tanaman. Ini akan membantu mengurangi kelembaban di sekitar daun dan menghambat pertumbuhan jamur."
        )
    )

    fun generateTeaList(): List<Tea> {
        val teaList = mutableListOf<Tea>()
        for (teaData in data) {
            val tea = Tea(
                teaData[0] as Int,
                teaData[1] as String,
                teaData[2] as String,
                teaData[3] as String,
                teaData[4] as String
            )
            teaList.add(tea)
        }
        return teaList
    }
}
