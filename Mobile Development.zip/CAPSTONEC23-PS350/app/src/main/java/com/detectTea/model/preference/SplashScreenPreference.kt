package com.detectTea.model.preference

import android.content.Context
import android.content.SharedPreferences

class SplashScreenPreference(context: Context) {
    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("MyFirstTime", Context.MODE_PRIVATE)

    fun saveFirstTime(firstTime: String) {
        val editor = sharedPreferences.edit()
        editor.putString("firstTime", firstTime)
        editor.apply()
    }

    fun isFirstTime(): Boolean {
        return sharedPreferences.contains("username")
    }
}