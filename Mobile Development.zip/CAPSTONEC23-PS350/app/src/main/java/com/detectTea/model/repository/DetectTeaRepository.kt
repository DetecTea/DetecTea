package com.detectTea.model.repository

import com.detectTea.model.Api.ApiService

class DetectTeaRepository(
    private val apiService: ApiService
) {

}